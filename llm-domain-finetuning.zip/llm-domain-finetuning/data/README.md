# Dataset and licensing

`raw_tickets.jsonl` is a small synthetic dataset authored for this repository. It contains no real people, organizations, credentials, incidents, or customer data. The dataset is dedicated to the public domain under **CC0 1.0 Universal** (see `data/DATASET_LICENSE.txt`). It is deliberately small for reproducible learning, not representative of a production help desk.

Each JSONL row has `id`, `ticket`, `category`, `priority`, and `action`. Categories are `access`, `network`, `hardware`, `software`, and `security`; priorities are `low`, `medium`, `high`, and `critical`. Run `python -m helpdesk_ft.data` to create deterministic stratified train/validation/test splits under `data/splits/`. The split files are generated from the included source and can be recreated with seed 42.

For real use, replace this data only with tickets you are authorized to process, remove personal data, document the dataset's license and provenance, and review privacy/security implications before training.
