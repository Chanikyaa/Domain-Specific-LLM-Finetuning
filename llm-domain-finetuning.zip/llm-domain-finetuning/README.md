# Domain-Specific LLM Fine-Tuning: IT Help-Desk Triage

A reproducible lab for adapting a small open-weight language model to return structured IT ticket triage suggestions, using supervised fine-tuning with **PEFT LoRA**. The project compares a transparent rule baseline, base-model prompting, and the adapted model on a held-out test split; it does not assume fine-tuning is better.

## Problem and intended users

Support teams often need a consistent initial category, priority, and safe next-step recommendation for incoming IT requests. This repository demonstrates the data and evaluation workflow behind adapting a small LLM to that narrow task. It is intended for ML engineers learning fine-tuning, evaluation, and model serving.

**Non-goals:** production incident response, automated ticket creation, account changes, security remediation, training on private organizational tickets, or claiming that synthetic-data results generalize to a real help desk.

## Features

- 80 included synthetic CC0 examples across five categories and four priority levels.
- Schema validation and deterministic splits grouped by underlying issue to avoid paraphrase leakage.
- Transparent rule-based baseline that runs without downloading a model.
- Base-model prompting and LoRA adapter evaluation using the same held-out tickets.
- LoRA fine-tuning with prompt-token loss masking, fixed seed, validation-loss checkpoint selection, and training manifest.
- JSON validity, category accuracy/macro-F1, priority accuracy, category/priority exact match, latency, optional GPU-memory measurement, and error examples.
- Optional FastAPI endpoint, Docker setup, tests, and GitHub Actions CI.

## Architecture

See [`docs/architecture.md`](docs/architecture.md) for the Mermaid diagram and component boundaries. The default base model is `HuggingFaceTB/SmolLM2-135M-Instruct`; no third-party weights are bundled. Model weights are downloaded only when you run training or base/adapter model evaluation.

## Prerequisites

- Python 3.10–3.12.
- For data checks, tests, rule baseline and default API: CPU is sufficient and no model download is required.
- For actual fine-tuning or model generation: install the optional `train` or `eval` dependencies. PyTorch CPU works but may be slow; a small GPU is recommended for iteration, not required by the code.
- Internet access is needed on the first model download unless the model is already cached.

## Installation

```bash
python -m venv .venv
source .venv/bin/activate  # Windows PowerShell: .venv\\Scripts\\Activate.ps1
python -m pip install -e '.[dev,api]'
```

Install the optional fine-tuning stack only when needed:

```bash
python -m pip install -e '.[train]'
```

To evaluate a base model without training, install `.[eval]`. Keep downloaded weights in your local Hugging Face cache; do not commit weights or secrets.

## Reproducible workflow

### 1. Validate and split data

```bash
python -m helpdesk_ft.data --seed 42
```

Expected split counts are recorded in `data/splits/manifest.json`. Splitting groups both wording variants of the same underlying issue together to prevent near-duplicate leakage.

### 2. Run the no-download baseline

```bash
python -m helpdesk_ft.evaluate --mode rule --output outputs/rule-evaluation.json
```

### 3. Evaluate the base model with prompting

```bash
python -m pip install -e '.[eval]'
python -m helpdesk_ft.evaluate --mode base \
  --model-name HuggingFaceTB/SmolLM2-135M-Instruct \
  --output outputs/base-model-evaluation.json
```

### 4. Fine-tune with LoRA

```bash
python -m helpdesk_ft.train --config configs/train.yaml
```

This writes adapter weights and `training_manifest.json` under `outputs/smol-lora/`. The default configuration is deliberately small (2 epochs, batch size 2, gradient accumulation 4, LoRA rank 8). Adjust epochs and sequence length only after checking resources and held-out performance.

### 5. Compare base and adapted models

```bash
python -m helpdesk_ft.evaluate --mode compare \
  --model-name HuggingFaceTB/SmolLM2-135M-Instruct \
  --adapter-path outputs/smol-lora/adapter \
  --output outputs/model-comparison.json
```

Open the JSON report and inspect `error_analysis.examples`. Do not claim the adapted model is better unless the measured held-out results support it. The test split is small and synthetic; use it to verify the workflow, not to estimate real-world accuracy.

## API

Start the rule-baseline API without downloading weights:

```bash
uvicorn helpdesk_ft.api:app --reload
```

Example request:

```bash
curl -X POST http://127.0.0.1:8000/triage \
  -H 'Content-Type: application/json' \
  -d '{"ticket":"I entered my password into a suspicious login page"}'
```

Example response shape (action text can vary by backend):

```json
{
  "category": "security",
  "priority": "critical",
  "action": "Do not take further action on the suspicious item; contact the security team through a trusted channel."
}
```

To opt into adapter inference, install `.[eval]`, set `HF_ADAPTER_PATH` to the adapter directory and optionally `HF_MODEL_NAME`, then restart the API. The adapter path must be compatible with the selected base model. If model inference fails, the endpoint returns an error; it does not silently fall back to the rule baseline after adapter mode has been selected.

API docs: `http://127.0.0.1:8000/docs`. Health check: `GET /health`.

## Tests and CI

```bash
python -m pip install -e '.[dev,api]'
python -m helpdesk_ft.data
pytest -q
python -m helpdesk_ft.evaluate --mode rule --output outputs/test-evaluation.json
```

The test suite covers dataset schema and IDs, deterministic leakage-safe splits, invalid data, output parsing, metrics, conservative security triage, and API input/output validation. The CI workflow tests Python 3.10–3.12. Fine-tuning is excluded from CI because model downloads and GPU availability are not reliable CI assumptions.

## Evaluation and limitations

- **JSON validity:** fraction of generations that satisfy the output schema.
- **Category accuracy and macro-F1:** category classification quality, with macro-F1 giving each category equal weight.
- **Priority accuracy:** exact priority label match.
- **Category/priority exact match:** both labels must match.
- **Latency/memory:** per-example generation latency; CUDA peak allocation when available.
- **Error analysis:** stores ticket, gold output and system outputs for the first ten errors.

Action text is not scored semantically, and structured output validity does not establish that advice is safe or correct. The synthetic dataset is small and generated from templates, so its distribution is artificial. Base/adapted model scores must be generated locally and reported from actual artifacts; no fine-tuning result is prefilled or fabricated in this repository.

## Docker

The default image serves the lightweight rule baseline:

```bash
docker compose up --build
```

For adapter-backed inference, install the `eval` extra in the image and mount/cache the model weights and adapter securely; do not bake private or large model artifacts into a public image by default.

## Licensing, privacy, and security

- Repository code: MIT (`LICENSE`).
- Included synthetic dataset: CC0 1.0 (`data/DATASET_LICENSE.txt`).
- Base model: check its current model card and license before downloading or redistributing; the base weights are not bundled. See [`docs/licensing.md`](docs/licensing.md).
- Never include private tickets, personal data, passwords, access tokens, or confidential incident details in training files or evaluation logs.
- Treat model outputs as untrusted recommendations. Review security-related tickets with a qualified human. The demo has no external integrations and performs no actions.

## Engineering contribution

This repository implements the full fine-tuning experiment scaffold: schema-validated data ingestion, leakage-aware split generation, a transparent baseline, PEFT LoRA training, deterministic held-out evaluation, error reporting, optional model serving, test coverage, and repeatable run instructions.

## Future improvements

- Replace synthetic examples with an authorized, representative, licensed dataset.
- Add multiple seeds and confidence intervals.
- Evaluate action quality with blinded human review and a safety rubric.
- Track model and data revisions in experiment tracking, and record exact model commit hashes.
- Test quantized adapter inference and measure throughput under realistic concurrent load.
