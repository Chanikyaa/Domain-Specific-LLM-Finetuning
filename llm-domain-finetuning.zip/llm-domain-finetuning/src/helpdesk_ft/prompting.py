"""Shared prompt and output parsing helpers."""
import json
import re
from .schemas import TriageResult

SYSTEM_INSTRUCTION = (
    "You triage IT help-desk tickets. Choose a category from access, network, hardware, software, security. "
    "Choose priority low, medium, high, or critical. Give a safe concise next action. "
    "Return exactly one JSON object with keys category, priority, action. Never invent that an action was completed."
)


def make_prompt(ticket: str) -> str:
    return f"### Instructions\n{SYSTEM_INSTRUCTION}\n\n### Ticket\n{ticket.strip()}\n\n### JSON response\n"


def make_target(row: dict) -> str:
    return json.dumps({"category": row["category"], "priority": row["priority"], "action": row["action"]}, ensure_ascii=False)


def parse_result(text: str) -> TriageResult | None:
    """Parse the first JSON object, rejecting unknown labels and malformed output."""
    candidates = re.findall(r"\{.*?\}", text, flags=re.DOTALL)
    for candidate in candidates:
        try:
            value = json.loads(candidate)
            return TriageResult.model_validate(value)
        except (json.JSONDecodeError, ValueError):
            continue
    return None
