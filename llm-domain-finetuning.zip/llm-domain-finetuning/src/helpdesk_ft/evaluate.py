"""Evaluate rule, base-model prompting, and LoRA-adapted generation on held-out data."""
import argparse
import json
import math
import time
from pathlib import Path

from .baseline import rule_triage
from .data import DEFAULT_OUT, read_jsonl
from .metrics import score_predictions
from .prompting import make_prompt, parse_result

ROOT = Path(__file__).resolve().parents[2]


def generate_with_model(rows: list[dict], model_name: str, adapter_path: Path | None = None, max_new_tokens: int = 110) -> tuple[list[dict | None], dict]:
    try:
        import torch
        from peft import PeftModel
        from transformers import AutoModelForCausalLM, AutoTokenizer
    except ImportError as exc:
        raise RuntimeError("Model evaluation dependencies missing. Install with: pip install -e '.[eval]'") from exc
    tokenizer = AutoTokenizer.from_pretrained(str(adapter_path) if adapter_path and (adapter_path / "tokenizer_config.json").exists() else model_name)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    device = "cuda" if torch.cuda.is_available() else "cpu"
    if device == "cuda":
        torch.cuda.reset_peak_memory_stats()
    model = AutoModelForCausalLM.from_pretrained(model_name).to(device)
    if adapter_path is not None:
        model = PeftModel.from_pretrained(model, str(adapter_path))
    model.eval()
    predictions: list[dict | None] = []
    latencies = []
    for row in rows:
        prompt = make_prompt(row["ticket"])
        inputs = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=512).to(device)
        start = time.perf_counter()
        with torch.inference_mode():
            generated = model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                do_sample=False,
                pad_token_id=tokenizer.pad_token_id,
                eos_token_id=tokenizer.eos_token_id,
            )
        latencies.append(time.perf_counter() - start)
        new_tokens = generated[0][inputs["input_ids"].shape[1]:]
        decoded = tokenizer.decode(new_tokens, skip_special_tokens=True)
        parsed = parse_result(decoded)
        predictions.append(parsed.model_dump() if parsed else None)
    resource = {
        "device": device,
        "mean_latency_seconds": sum(latencies) / len(latencies) if latencies else None,
        "p95_latency_seconds": sorted(latencies)[max(0, math.ceil(0.95 * len(latencies)) - 1)] if latencies else None,
    }
    if device == "cuda":
        resource["peak_gpu_memory_mb"] = torch.cuda.max_memory_allocated() / (1024 * 1024)
    del model
    return predictions, resource


def evaluate(data_dir: Path = DEFAULT_OUT, mode: str = "rule", model_name: str = "HuggingFaceTB/SmolLM2-135M-Instruct", adapter_path: Path | None = None, output_path: Path = Path("outputs/evaluation.json")) -> dict:
    rows = read_jsonl(data_dir / "test.jsonl")
    gold = [{"category": r["category"], "priority": r["priority"], "action": r["action"]} for r in rows]
    reports: dict[str, dict] = {}
    all_preds: dict[str, list[dict | None]] = {}
    if mode in ("rule", "compare"):
        start = time.perf_counter()
        preds = [rule_triage(row["ticket"]).model_dump() for row in rows]
        reports["rule_baseline"] = {**score_predictions(gold, preds), "mean_latency_seconds": (time.perf_counter()-start)/len(rows), "device": "cpu"}
        all_preds["rule_baseline"] = preds
    if mode in ("base", "compare"):
        preds, resources = generate_with_model(rows, model_name)
        reports["base_model_prompting"] = {**score_predictions(gold, preds), **resources}
        all_preds["base_model_prompting"] = preds
    if mode in ("adapter", "compare"):
        if adapter_path is None:
            raise ValueError("--adapter-path is required for adapter or compare mode")
        preds, resources = generate_with_model(rows, model_name, adapter_path)
        reports["lora_adapter"] = {**score_predictions(gold, preds), **resources}
        all_preds["lora_adapter"] = preds
    errors = []
    for index, row in enumerate(rows):
        record = {"id": row["id"], "ticket": row["ticket"], "gold": gold[index]}
        record["predictions"] = {name: preds[index] for name, preds in all_preds.items()}
        if any(preds[index] is None or preds[index].get("category") != gold[index]["category"] or preds[index].get("priority") != gold[index]["priority"] for preds in all_preds.values()):
            errors.append(record)
    report = {
        "dataset": str(data_dir / "test.jsonl"),
        "model_name": model_name if mode in ("base", "adapter", "compare") else None,
        "mode": mode,
        "metrics": reports,
        "error_analysis": {"count_with_category_or_priority_error": len(errors), "examples": errors[:10]},
        "limitations": ["Synthetic, small evaluation set; results do not establish production generalization.", "Action quality is not scored semantically; exact text can vary.", "Generated output is parsed and schema-validated, but must not trigger real actions without human review."],
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--mode", choices=["rule", "base", "adapter", "compare"], default="rule")
    parser.add_argument("--model-name", default="HuggingFaceTB/SmolLM2-135M-Instruct")
    parser.add_argument("--adapter-path", type=Path, default=None)
    parser.add_argument("--output", type=Path, default=Path("outputs/evaluation.json"))
    args = parser.parse_args()
    print(json.dumps(evaluate(args.data_dir, args.mode, args.model_name, args.adapter_path, args.output), indent=2))

if __name__ == "__main__":
    main()
