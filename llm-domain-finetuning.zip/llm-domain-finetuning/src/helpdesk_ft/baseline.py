"""Transparent rule-based baseline; included alongside the actual base-model baseline."""
from .schemas import TriageResult

RULES = [
    ("security", ("password into", "mfa", "suspicious", "phishing", "endpoint protection", "usb drive", "bank details", "certificate is invalid")),
    ("network", ("wi-fi", "wifi", "vpn", "internet access", "dns", "packet loss", "ethernet", "network")),
    ("hardware", ("battery", "monitor flickers", "keyboard", "storage array", "fan runs", "webcam", "power on", "grinding noise")),
    ("access", ("sign in", "account is locked", "read-only", "folder", "revoke", "single sign-on", "permissions", "account access")),
    ("software", ("application crashes", "payroll application", "pdf reader", "ide update", "portal returns", "plugin disappeared", "ci runner", "spreadsheet application")),
]


def rule_triage(ticket: str) -> TriageResult:
    text = ticket.lower()
    category = "software"
    for label, needles in RULES:
        if any(needle in text for needle in needles):
            category = label
            break
    critical_terms = ("entire finance team", "all users", "all employees", "storage array", "production database", "entered my password", "mfa approval", "agent is disabled", "every employee")
    high_terms = ("cannot sign in", "locked", "vpn is down", "internal wiki", "overheats", "portal returns", "certificate", "ci runner", "suspicious")
    if any(term in text for term in critical_terms):
        priority = "critical"
    elif any(term in text for term in high_terms):
        priority = "high"
    elif any(term in text for term in ("please", "need help", "cannot", "not detected", "disappeared", "disconnects")):
        priority = "medium"
    else:
        priority = "low"
    if category == "security":
        action = "Do not take further action on the suspicious item; contact the security team through a trusted channel."
    elif category == "access":
        action = "Verify the requester and authorization before changing account permissions."
    elif category == "network":
        action = "Collect sanitized connection diagnostics and check network service health."
    elif category == "hardware":
        action = "Collect device details and arrange approved hardware diagnostics or service."
    else:
        action = "Collect the application version and sanitized error details, then follow the approved support process."
    return TriageResult(category=category, priority=priority, action=action)
