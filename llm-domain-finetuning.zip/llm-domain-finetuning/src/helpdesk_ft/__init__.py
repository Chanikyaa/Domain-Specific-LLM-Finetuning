"""Domain adaptation lab for structured help-desk ticket triage."""

__version__ = "0.1.0"
