"""Task-specific metrics for structured triage outputs."""
from collections import Counter


def score_predictions(gold: list[dict], predictions: list[dict | None]) -> dict:
    if len(gold) != len(predictions):
        raise ValueError("gold and predictions must have equal lengths")
    n = len(gold)
    if n == 0:
        raise ValueError("cannot score an empty evaluation set")
    valid = [p for p in predictions if p is not None]
    category_correct = sum(p is not None and p["category"] == g["category"] for g, p in zip(gold, predictions))
    priority_correct = sum(p is not None and p["priority"] == g["priority"] for g, p in zip(gold, predictions))
    exact_pair_correct = sum(p is not None and p["category"] == g["category"] and p["priority"] == g["priority"] for g, p in zip(gold, predictions))
    labels = sorted({row["category"] for row in gold})
    f1s = []
    for label in labels:
        tp = sum(p is not None and p["category"] == label and g["category"] == label for g, p in zip(gold, predictions))
        fp = sum(p is not None and p["category"] == label and g["category"] != label for g, p in zip(gold, predictions))
        fn = sum(g["category"] == label and (p is None or p["category"] != label) for g, p in zip(gold, predictions))
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        f1s.append(2 * precision * recall / (precision + recall) if precision + recall else 0.0)
    return {
        "examples": n,
        "valid_json_rate": len(valid) / n,
        "category_accuracy": category_correct / n,
        "category_macro_f1": sum(f1s) / len(f1s),
        "priority_accuracy": priority_correct / n,
        "category_priority_exact_match": exact_pair_correct / n,
    }
