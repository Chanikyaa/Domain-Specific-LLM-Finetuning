"""Optional local prediction API; use the LoRA adapter explicitly to serve the tuned model."""
import os
from functools import lru_cache
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, ConfigDict, Field
from .baseline import rule_triage
from .schemas import TriageResult

app = FastAPI(title="Helpdesk Fine-Tuning Lab", version="0.1.0", description="Synthetic IT ticket triage demo. Not for production incident handling.")


class TicketRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    ticket: str = Field(min_length=8, max_length=2000)


@lru_cache(maxsize=1)
def _load_model():
    adapter_path = os.getenv("HF_ADAPTER_PATH")
    if not adapter_path:
        return None
    try:
        import torch
        from peft import PeftModel
        from transformers import AutoModelForCausalLM, AutoTokenizer
    except ImportError as exc:
        raise RuntimeError("Install model dependencies with pip install -e '.[eval]'") from exc
    model_name = os.getenv("HF_MODEL_NAME", "HuggingFaceTB/SmolLM2-135M-Instruct")
    tokenizer = AutoTokenizer.from_pretrained(adapter_path)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    model = PeftModel.from_pretrained(AutoModelForCausalLM.from_pretrained(model_name), adapter_path)
    model.eval()
    return tokenizer, model, torch


def _model_triage(ticket: str) -> TriageResult:
    from .prompting import make_prompt, parse_result
    loaded = _load_model()
    if loaded is None:
        return rule_triage(ticket)
    tokenizer, model, torch = loaded
    device = next(model.parameters()).device
    inputs = tokenizer(make_prompt(ticket), return_tensors="pt", truncation=True, max_length=512).to(device)
    with torch.inference_mode():
        output = model.generate(**inputs, max_new_tokens=110, do_sample=False, pad_token_id=tokenizer.pad_token_id)
    generated = tokenizer.decode(output[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True)
    result = parse_result(generated)
    if result is None:
        raise HTTPException(status_code=502, detail="Model output did not match the required triage schema")
    return result


@app.get("/health")
def health() -> dict:
    return {"status": "ok", "backend": "lora_adapter" if os.getenv("HF_ADAPTER_PATH") else "rule_baseline"}


@app.post("/triage", response_model=TriageResult)
def triage(request: TicketRequest) -> TriageResult:
    try:
        return _model_triage(request.ticket)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=503, detail="Triage backend unavailable") from exc
