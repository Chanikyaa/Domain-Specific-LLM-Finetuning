"""Convenience entry point for splitting the bundled dataset."""
from .data import main

if __name__ == "__main__":
    main()
