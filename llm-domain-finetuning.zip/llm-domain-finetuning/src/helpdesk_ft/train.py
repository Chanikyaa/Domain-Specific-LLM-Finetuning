"""Parameter-efficient supervised fine-tuning using Transformers Trainer + PEFT LoRA."""
import argparse
import json
import random
from pathlib import Path

import yaml

from .data import DEFAULT_OUT, read_jsonl, write_splits
from .prompting import make_prompt, make_target


def seed_everything(seed: int) -> None:
    random.seed(seed)
    try:
        import numpy as np
        np.random.seed(seed)
    except ImportError:
        pass
    try:
        import torch
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
    except ImportError:
        pass


def train(config_path: Path, data_dir: Path, output_dir: Path) -> dict:
    try:
        import torch
        from peft import LoraConfig, TaskType, get_peft_model
        from transformers import AutoModelForCausalLM, AutoTokenizer, Trainer, TrainingArguments
    except ImportError as exc:
        raise RuntimeError("Training dependencies missing. Install with: pip install -e '.[train]'") from exc

    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    seed = int(config.get("seed", 42))
    seed_everything(seed)
    if not (data_dir / "train.jsonl").exists():
        write_splits(out_dir=data_dir, seed=seed)
    train_rows = read_jsonl(data_dir / "train.jsonl")
    val_rows = read_jsonl(data_dir / "validation.jsonl")
    model_name = str(config["model_name"])
    tokenizer = AutoTokenizer.from_pretrained(model_name, use_fast=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    model = AutoModelForCausalLM.from_pretrained(model_name)
    model.config.pad_token_id = tokenizer.pad_token_id
    lora = LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        r=int(config.get("lora_r", 8)),
        lora_alpha=int(config.get("lora_alpha", 16)),
        lora_dropout=float(config.get("lora_dropout", 0.05)),
        target_modules=list(config.get("target_modules", ["q_proj", "v_proj"])),
        bias="none",
    )
    model = get_peft_model(model, lora)
    model.print_trainable_parameters()

    class TicketDataset(torch.utils.data.Dataset):
        def __init__(self, rows: list[dict]):
            self.items = []
            max_length = int(config.get("max_length", 384))
            for row in rows:
                prompt = make_prompt(row["ticket"])
                full_text = prompt + make_target(row) + tokenizer.eos_token
                prefix_ids = tokenizer(prompt, add_special_tokens=False)["input_ids"]
                encoded = tokenizer(full_text, truncation=True, max_length=max_length, add_special_tokens=False)
                labels = encoded["input_ids"][:]
                prefix_length = min(len(prefix_ids), len(labels))
                labels[:prefix_length] = [-100] * prefix_length
                if all(label == -100 for label in labels):
                    raise ValueError(f"Example {row['id']} has no target tokens after truncation")
                self.items.append({"input_ids": encoded["input_ids"], "attention_mask": encoded["attention_mask"], "labels": labels})

        def __len__(self):
            return len(self.items)

        def __getitem__(self, index):
            return self.items[index]

    def collate(features: list[dict]) -> dict:
        max_len = max(len(item["input_ids"]) for item in features)
        input_ids, masks, labels = [], [], []
        for item in features:
            padding = max_len - len(item["input_ids"])
            input_ids.append(item["input_ids"] + [tokenizer.pad_token_id] * padding)
            masks.append(item["attention_mask"] + [0] * padding)
            labels.append(item["labels"] + [-100] * padding)
        return {
            "input_ids": torch.tensor(input_ids, dtype=torch.long),
            "attention_mask": torch.tensor(masks, dtype=torch.long),
            "labels": torch.tensor(labels, dtype=torch.long),
        }

    output_dir.mkdir(parents=True, exist_ok=True)
    args = TrainingArguments(
        output_dir=str(output_dir),
        num_train_epochs=float(config.get("num_train_epochs", 2)),
        learning_rate=float(config.get("learning_rate", 2e-4)),
        per_device_train_batch_size=int(config.get("per_device_train_batch_size", 2)),
        per_device_eval_batch_size=2,
        gradient_accumulation_steps=int(config.get("gradient_accumulation_steps", 4)),
        logging_steps=int(config.get("logging_steps", 5)),
        evaluation_strategy="steps",
        eval_steps=int(config.get("eval_steps", 10)),
        save_strategy="steps",
        save_steps=int(config.get("save_steps", 10)),
        save_total_limit=2,
        load_best_model_at_end=True,
        metric_for_best_model="eval_loss",
        greater_is_better=False,
        report_to=[],
        seed=seed,
        data_seed=seed,
        fp16=bool(torch.cuda.is_available() and config.get("fp16", False)),
        use_cpu=not torch.cuda.is_available(),
    )
    trainer = Trainer(
        model=model,
        args=args,
        train_dataset=TicketDataset(train_rows),
        eval_dataset=TicketDataset(val_rows),
        data_collator=collate,
        tokenizer=tokenizer,
    )
    result = trainer.train()
    trainer.save_model(str(output_dir / "adapter"))
    tokenizer.save_pretrained(str(output_dir / "adapter"))
    eval_metrics = trainer.evaluate()
    manifest = {
        "base_model": model_name,
        "seed": seed,
        "train_examples": len(train_rows),
        "validation_examples": len(val_rows),
        "train_runtime_seconds": result.metrics.get("train_runtime"),
        "train_samples_per_second": result.metrics.get("train_samples_per_second"),
        "validation_loss": eval_metrics.get("eval_loss"),
        "trainable_parameters": sum(p.numel() for p in model.parameters() if p.requires_grad),
        "total_parameters": sum(p.numel() for p in model.parameters()),
    }
    (output_dir / "training_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=Path("configs/train.yaml"))
    parser.add_argument("--data-dir", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--output-dir", type=Path, default=None)
    args = parser.parse_args()
    config = yaml.safe_load(args.config.read_text(encoding="utf-8"))
    output = args.output_dir or Path(config.get("output_dir", "outputs/smol-lora"))
    print(json.dumps(train(args.config, args.data_dir, output), indent=2))

if __name__ == "__main__":
    main()
