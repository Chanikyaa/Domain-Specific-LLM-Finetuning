"""Dataset loading, validation, and deterministic stratified splitting."""
import argparse
import json
import random
from pathlib import Path

from pydantic import ValidationError
from .schemas import TicketRecord

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_SOURCE = ROOT / "data" / "raw_tickets.jsonl"
DEFAULT_OUT = ROOT / "data" / "splits"


def read_jsonl(path: Path) -> list[dict]:
    rows = []
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            value = json.loads(line)
            rows.append(TicketRecord.model_validate(value).model_dump())
        except (json.JSONDecodeError, ValidationError) as exc:
            raise ValueError(f"Invalid dataset row at {path}:{line_number}: {exc}") from exc
    if not rows:
        raise ValueError(f"Dataset is empty: {path}")
    ids = [row["id"] for row in rows]
    if len(ids) != len(set(ids)):
        raise ValueError("Dataset contains duplicate ids")
    return rows


def split_rows(rows: list[dict], seed: int = 42) -> dict[str, list[dict]]:
    """Split by underlying issue, keeping paraphrase variants in the same partition."""
    rng = random.Random(seed)
    groups: dict[str, list[dict]] = {}
    for row in rows:
        # IDs end in variant number; group sibling paraphrases to prevent leakage.
        group_id = row["id"].rsplit("-", 1)[0]
        groups.setdefault(group_id, []).append(row)
    by_category: dict[str, list[list[dict]]] = {}
    for group_id, examples in groups.items():
        by_category.setdefault(examples[0]["category"], []).append(examples)
    out = {"train": [], "validation": [], "test": []}
    for category in sorted(by_category):
        category_groups = by_category[category][:]
        rng.shuffle(category_groups)
        n = len(category_groups)
        if n < 3:
            raise ValueError(f"Each category needs at least 3 distinct issues: {category}")
        n_test = max(1, round(n * 0.2))
        n_val = max(1, round(n * 0.15))
        if n_test + n_val >= n:
            n_test, n_val = 1, 1
        for split_name, selected in (("test", category_groups[:n_test]),
                                     ("validation", category_groups[n_test:n_test+n_val]),
                                     ("train", category_groups[n_test+n_val:])):
            for issue_group in selected:
                out[split_name].extend(issue_group)
    for split in out.values():
        rng.shuffle(split)
    return out


def write_splits(source: Path = DEFAULT_SOURCE, out_dir: Path = DEFAULT_OUT, seed: int = 42) -> dict[str, int]:
    rows = read_jsonl(source)
    splits = split_rows(rows, seed)
    out_dir.mkdir(parents=True, exist_ok=True)
    for name, split in splits.items():
        (out_dir / f"{name}.jsonl").write_text(
            "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in split), encoding="utf-8"
        )
    manifest = {"source": source.name, "seed": seed, "counts": {k: len(v) for k, v in splits.items()}}
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return manifest["counts"]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=DEFAULT_SOURCE)
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    print(json.dumps(write_splits(args.source, args.out_dir, args.seed), indent=2))

if __name__ == "__main__":
    main()
