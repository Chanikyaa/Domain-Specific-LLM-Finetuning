"""Input and output contracts shared by data validation, evaluation, and API."""
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, field_validator

Category = Literal["access", "network", "hardware", "software", "security"]
Priority = Literal["low", "medium", "high", "critical"]


class TicketRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")
    id: str = Field(min_length=1, max_length=80)
    ticket: str = Field(min_length=8, max_length=2000)
    category: Category
    priority: Priority
    action: str = Field(min_length=8, max_length=400)

    @field_validator("ticket", "action")
    @classmethod
    def strip_text(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("must not be blank")
        return value


class TriageResult(BaseModel):
    model_config = ConfigDict(extra="forbid")
    category: Category
    priority: Priority
    action: str = Field(min_length=8, max_length=400)
