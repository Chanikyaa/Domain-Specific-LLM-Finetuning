"""Regenerate the CC0 synthetic ticket dataset from transparent templates."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CASES = {
    "access": [
        ("I cannot sign in to my account after changing my password", "high", "Verify identity through the approved process, then help reset account access."),
        ("Please add the new analyst to the read-only reporting group", "medium", "Confirm manager approval and grant only the requested least-privilege group."),
        ("My account is locked after several incorrect login attempts", "high", "Verify the requester and follow the account-unlock procedure."),
        ("A contractor needs access to the shared project folder today", "medium", "Confirm sponsorship and folder authorization before granting time-limited access."),
        ("I need to remove access for a teammate who changed teams", "high", "Validate the change request and remove obsolete permissions with an audit record."),
        ("Can I get access to the internal documentation portal", "low", "Share the access request process and verify eligibility."),
        ("The single sign-on page loops back to the login screen", "high", "Check identity-provider status and collect sanitized sign-in diagnostics."),
        ("Please revoke a forgotten test account", "medium", "Confirm ownership and deprovision the unused account according to policy."),
    ],
    "network": [
        ("The office Wi-Fi disconnects every few minutes on my laptop", "medium", "Check access-point status, device drivers, and connection logs."),
        ("VPN is down for the entire finance team before month end", "critical", "Escalate to network on-call and verify VPN gateway health and impact."),
        ("I cannot reach the internal wiki while connected to VPN", "high", "Check DNS, routes, and VPN policy using sanitized diagnostics."),
        ("Video calls have been choppy since this morning", "medium", "Measure packet loss and latency, then inspect local and upstream network load."),
        ("A single website times out from the guest network", "low", "Check whether the site is blocked by guest-network policy and test connectivity."),
        ("All users in the branch office have lost internet access", "critical", "Page network on-call and inspect edge-router and provider connectivity."),
        ("DNS lookup for the internal build server fails", "high", "Validate resolver health and the relevant DNS record."),
        ("The ethernet port at desk 14 has no link light", "low", "Check cable and switch-port status, then arrange a port test if needed."),
    ],
    "hardware": [
        ("My laptop battery drains in less than one hour", "medium", "Collect device model and battery diagnostics, then assess battery replacement."),
        ("The shared production database server is making a loud grinding noise", "critical", "Escalate to infrastructure on-call and follow the hardware incident procedure."),
        ("The external monitor flickers when connected to my dock", "low", "Test a known-good cable and port, then check dock firmware compatibility."),
        ("My keyboard keys are sticking after normal use", "low", "Arrange approved cleaning or replacement and avoid exposing device data."),
        ("The storage array reports a failed drive and degraded redundancy", "critical", "Notify storage on-call immediately and follow the documented recovery runbook."),
        ("Laptop fan runs loudly and the device overheats", "high", "Check thermal diagnostics and arrange hardware inspection to prevent damage."),
        ("The meeting-room webcam is not detected by the desktop", "medium", "Check USB connection, device permissions, and a known-good port."),
        ("My workstation will not power on after a power outage", "high", "Check power supply and asset status; arrange technician assessment."),
    ],
    "software": [
        ("The spreadsheet application crashes when opening a large file", "medium", "Collect application version and sanitized crash logs, then test safe mode."),
        ("The payroll application is unavailable for every employee", "critical", "Escalate to the payroll application owner and check service health."),
        ("I need help installing the approved PDF reader", "low", "Use the managed software catalog and confirm the approved package."),
        ("The latest IDE update broke the local build process", "medium", "Capture the version change and build error, then test the supported toolchain."),
        ("The customer portal returns errors after deployment", "high", "Notify the service owner, inspect deployment health, and follow rollback policy."),
        ("My calendar plugin disappeared after an update", "low", "Check plugin compatibility and restore it through the approved software channel."),
        ("The CI runner cannot download dependencies for any project", "high", "Check package registry status, runner networking, and recent configuration changes."),
        ("The desktop application displays a certificate validation error", "high", "Verify system time and certificate chain; do not bypass certificate checks."),
    ],
    "security": [
        ("I entered my password into a suspicious login page", "critical", "Treat as a potential compromise: contact security immediately and follow credential containment procedures."),
        ("An unexpected MFA approval request appeared on my phone", "critical", "Deny the request and contact security through a trusted channel immediately."),
        ("A file attachment was quarantined by endpoint protection", "high", "Do not restore or open the file; submit the alert to the security team."),
        ("I found an unfamiliar USB drive in the office", "high", "Do not connect it; report its location to security for safe handling."),
        ("A vendor email asks me to change bank details urgently", "high", "Do not act on the email; verify via a known trusted channel and report it."),
        ("The endpoint protection agent is disabled on my laptop", "critical", "Contact security operations immediately and avoid sensitive work until remediated."),
        ("I received a routine security awareness training reminder", "low", "Direct the user to the approved training portal and due date."),
        ("A browser warns that a certificate is invalid on an internal page", "high", "Do not bypass the warning; report the URL and timestamp to security."),
    ],
}

PREFIXES = ["Please help: ", "Issue reported — ", "User says: ", "Support request: "]
rows = []
for category, cases in CASES.items():
    for idx, (ticket, priority, action) in enumerate(cases):
        for variant, prefix in enumerate(PREFIXES[:2]):
            rows.append({
                "id": f"{category}-{idx+1:02d}-{variant+1}",
                "ticket": (prefix + ticket + ("." if not ticket.endswith(".") else "")),
                "category": category,
                "priority": priority,
                "action": action,
            })
path = ROOT / "data" / "raw_tickets.jsonl"
path.write_text("".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows), encoding="utf-8")
print(f"Wrote {len(rows)} synthetic examples to {path}")
