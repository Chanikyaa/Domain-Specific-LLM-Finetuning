from fastapi.testclient import TestClient
from helpdesk_ft.api import app

client = TestClient(app)


def test_health_defaults_to_rule_baseline(monkeypatch):
    monkeypatch.delenv("HF_ADAPTER_PATH", raising=False)
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["backend"] == "rule_baseline"


def test_triage_endpoint_validates_and_returns_schema(monkeypatch):
    monkeypatch.delenv("HF_ADAPTER_PATH", raising=False)
    response = client.post("/triage", json={"ticket": "I entered my password into a suspicious login page"})
    assert response.status_code == 200
    assert response.json()["category"] == "security"
    assert response.json()["priority"] == "critical"


def test_triage_rejects_extra_fields():
    response = client.post("/triage", json={"ticket": "The office Wi-Fi disconnects every few minutes", "action": "do something"})
    assert response.status_code == 422
