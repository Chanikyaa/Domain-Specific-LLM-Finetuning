import json
from pathlib import Path
import pytest
from helpdesk_ft.data import read_jsonl, split_rows

ROOT = Path(__file__).resolve().parents[1]


def test_dataset_schema_and_unique_ids():
    rows = read_jsonl(ROOT / "data" / "raw_tickets.jsonl")
    assert len(rows) == 80
    assert len({row["id"] for row in rows}) == len(rows)
    assert {row["category"] for row in rows} == {"access", "network", "hardware", "software", "security"}


def test_split_is_reproducible_and_no_sibling_variant_leakage():
    rows = read_jsonl(ROOT / "data" / "raw_tickets.jsonl")
    a, b = split_rows(rows, 42), split_rows(rows, 42)
    assert {k: [r["id"] for r in v] for k, v in a.items()} == {k: [r["id"] for r in v] for k, v in b.items()}
    seen = {}
    for split, values in a.items():
        for row in values:
            group = row["id"].rsplit("-", 1)[0]
            assert group not in seen or seen[group] == split
            seen[group] = split


def test_invalid_rows_are_rejected(tmp_path: Path):
    bad = tmp_path / "bad.jsonl"
    bad.write_text(json.dumps({"id": "x", "ticket": "short", "category": "alien", "priority": "urgent", "action": "x"}))
    with pytest.raises(ValueError, match="Invalid dataset row"):
        read_jsonl(bad)
