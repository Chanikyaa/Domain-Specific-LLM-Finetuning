from helpdesk_ft.baseline import rule_triage
from helpdesk_ft.metrics import score_predictions
from helpdesk_ft.prompting import make_prompt, parse_result


def test_prompt_contains_ticket_and_json_instruction():
    prompt = make_prompt("VPN is down for the whole office")
    assert "VPN is down" in prompt
    assert "JSON object" in prompt


def test_parse_valid_and_reject_invalid_model_output():
    valid = parse_result('some text {"category":"network","priority":"high","action":"Check sanitized network logs."}')
    assert valid is not None and valid.category == "network"
    assert parse_result('{"category":"fake","priority":"urgent","action":"do something safe"}') is None
    assert parse_result("not json") is None


def test_rule_baseline_security_is_conservative():
    result = rule_triage("I entered my password into a suspicious login page")
    assert result.category == "security"
    assert result.priority == "critical"
    assert "security" in result.action


def test_metrics_count_malformed_output_as_incorrect():
    gold = [{"category": "network", "priority": "high"}, {"category": "security", "priority": "critical"}]
    report = score_predictions(gold, [{"category": "network", "priority": "high"}, None])
    assert report["valid_json_rate"] == 0.5
    assert report["category_accuracy"] == 0.5
    assert report["priority_accuracy"] == 0.5
    assert report["category_priority_exact_match"] == 0.5
