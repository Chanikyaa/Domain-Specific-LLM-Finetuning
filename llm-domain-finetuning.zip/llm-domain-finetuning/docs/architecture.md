# Architecture and design decisions

```mermaid
flowchart TD
  A[CC0 synthetic JSONL] --> B[Schema validation]
  B --> C[Deterministic grouped split]
  C --> D[Prompting baseline]
  C --> E[Base model generation]
  C --> F[PEFT LoRA supervised fine-tuning]
  F --> G[Adapter artifact + manifest]
  D --> H[Held-out metrics + error examples]
  E --> H
  G --> I[Adapter evaluation]
  I --> H
  G --> J[Optional FastAPI model backend]
  J --> K[Schema-validated triage result]
```

## Boundaries

- Data: only the included synthetic tickets by default; never upload real support tickets to public model services.
- Training: Transformers Trainer with a causal-language-model objective and LoRA adapter weights. Prompt tokens are masked from the loss; target JSON tokens contribute to loss.
- Evaluation: fixed held-out split, deterministic greedy generation, valid-output rate, category accuracy and macro-F1, priority accuracy, category/priority exact match, latency, and optional GPU peak allocation.
- Serving: `HF_ADAPTER_PATH` opts into a real adapter. Without it, the API uses an explicit deterministic rule baseline. Both return the same validated schema.
- Safety: output is a recommendation only. No ticketing system integration or automatic account/security action exists.

## Why LoRA?

LoRA freezes the base model and trains a small set of low-rank adapter matrices, reducing trainable parameter count and adapter artifact size. This makes the exercise feasible on a modest GPU and allows an easy comparison against the unchanged base model. CPU training is supported by the script but can be slow; the rule baseline and tests require no model download.
