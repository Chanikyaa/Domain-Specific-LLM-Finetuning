# Model and data licensing

- Dataset: `data/raw_tickets.jsonl` is synthetic and dedicated under CC0 1.0; see `data/DATASET_LICENSE.txt`.
- Suggested base model: `HuggingFaceTB/SmolLM2-135M-Instruct`. Check the model card and license on the model host at the time you download it, and preserve the exact model revision in any published experiment manifest. Model weights and terms are separate from this repository's MIT software license.
- The code does not bundle third-party weights. The first Transformers run downloads model files from the model host unless cached locally.
- Do not fine-tune on internal DRDO/BuildFlow materials, private tickets, secrets, or personal information without explicit authorization and an appropriate data governance review.
