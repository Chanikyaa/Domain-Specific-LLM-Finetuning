# Verified local results

Environment used for the no-model path: Python 3.13, Pydantic 2.13.5, FastAPI 0.128.2, Pytest 9.0.2. This environment did not have `transformers` or `peft` installed, so a base-model generation run and actual LoRA training were **not executed** here. Those optional paths must be run in an environment with the declared extras and model download/cache available.

## Rule baseline on the held-out synthetic test split

The report at `reports/rule-baseline-evaluation.json` was generated locally from the deterministic split (`data/splits/test.jsonl`, 20 rows):

- Valid schema output: 1.00
- Category accuracy: 0.80
- Category macro-F1: 0.80
- Priority accuracy: 0.35
- Category + priority exact match: 0.30
- Mean rule execution time: approximately 0.000016 seconds per ticket in this run
- Error analysis: 14/20 examples had at least one category or priority error

This intentionally modest baseline shows why the task needs evaluation rather than relying on plausible output. These are results for the **rule baseline only**, not a base LLM or fine-tuned model, and the dataset is small and synthetic. Do not present these figures as evidence that fine-tuning improves performance.
