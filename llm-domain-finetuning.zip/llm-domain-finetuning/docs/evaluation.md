# Evaluation protocol

1. Split by underlying issue ID so near-duplicate phrasing variants never cross train/validation/test boundaries.
2. Use validation loss to select the best saved adapter checkpoint.
3. Run greedy decoding on the untouched test set for both the base model and adapter.
4. Report JSON validity, category accuracy and macro-F1, priority accuracy, exact match of category + priority, mean and p95 latency, and peak GPU memory if CUDA is available.
5. Inspect up to ten errors with ticket text, gold labels, and each system's prediction. Action text is not given a semantic quality score, so do not infer safe operational performance from classification scores alone.
6. Compare the model outputs with the transparent rule baseline. Fine-tuning should only be described as better if repeated held-out evaluation supports that conclusion.

The bundled dataset has 80 synthetic rows but only 40 underlying issue groups. That is intentionally a small learning demonstration, not a representative benchmark. Because the variants are grouped together, a typical split contains about 50 training rows, 10 validation rows, and 20 test rows. Report actual run artifacts rather than copying example metrics into the README.
